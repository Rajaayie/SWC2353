let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Function to add item to cart
function addToCart(event) {
    const button = event.target;
    const itemName = button.dataset.name;
    const itemPrice = parseFloat(button.dataset.price);
    const itemImage = button.dataset.image;
    const itemSize = document.getElementById('size').value;
    const itemColour = document.getElementById('colour').value;

    // Check if the item already exists in the cart
    const existingItem = cart.find(
        item => item.name === itemName && item.size === itemSize && item.colour === itemColour
    );

    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            name: itemName,
            price: itemPrice,
            image: itemImage,
            size: itemSize,
            colour: itemColour,
            quantity: 1
        });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    window.location.href = 'cart.html';
}

function renderCart() {
    const cartItemsContainer = document.getElementById('cart-items');
    cartItemsContainer.innerHTML = ''; // Clear existing content

    let subtotal = 0;

    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<tr><td colspan="3">Your cart is empty.</td></tr>';
        return;
    }

    cart.forEach((item, index) => {
        const itemTotal = item.price * item.quantity;
        subtotal += itemTotal;

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>
                <img src="${item.image}" alt="${item.name}" style="width: 50px;">
                <div>${item.name} (Size: ${item.size}, Colour: ${item.colour})</div>
            </td>
            <td>
                <button onclick="updateQuantity(${index}, -1)">-</button>
                ${item.quantity}
                <button onclick="updateQuantity(${index}, 1)">+</button>
            </td>
            <td>
                RM ${itemTotal.toFixed(2)}
                <button class="remove-item" onclick="removeItem(${index})">Remove</button>
            </td>
        `;
        cartItemsContainer.appendChild(row);
    });

    document.querySelector('.subtotal-section span').textContent = `RM ${subtotal.toFixed(2)}`;
}
function removeItem(index) {
    cart.splice(index, 1); // Remove the item at the given index
    localStorage.setItem('cart', JSON.stringify(cart)); // Update localStorage
    renderCart(); // Re-render the cart
}



function updateQuantity(index, change) {
    cart[index].quantity += change;
    if (cart[index].quantity < 1) cart[index].quantity = 1;
    localStorage.setItem('cart', JSON.stringify(cart));
    renderCart();
}

window.onload = renderCart;


