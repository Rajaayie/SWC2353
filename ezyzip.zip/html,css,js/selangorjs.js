// Initialize cart from localStorage or as an empty array if not available
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Adjust the quantity based on button clicks
function adjustQuantity(change) {
    const quantityInput = document.getElementById('quantity');
    let quantity = parseInt(quantityInput.value);
    quantity += change;
    if (quantity < 1) quantity = 1; // Ensure quantity is at least 1
    quantityInput.value = quantity;
}

// Function to add item to cart
function addToCart(event) {
    const button = event.target;
    const productName = button.dataset.name;
    const productPrice = parseFloat(button.dataset.price);
    const itemImage = button.dataset.image; // Get the product image from data attribute
    const size = document.getElementById('size').value;
    const quantity = parseInt(document.getElementById('quantity').value);

    if (!size) {
        alert("Please select a size.");
        return;
    }

    // Check if the item already exists in the cart
    const existingItem = cart.find(item => item.name === productName && item.size === size);
    if (existingItem) {
        existingItem.quantity += quantity; // Increase quantity if item already in cart with the same size
    } else {
        // Add new item with selected size, quantity, and image
        cart.push({ name: productName, price: productPrice, image: itemImage, size: size, quantity: quantity });
    }

    // Update cart in localStorage
    localStorage.setItem('cart', JSON.stringify(cart));

    // Confirm addition and navigate to cart
    alert("Item added to cart!");
    window.location.href = 'cart.html';
}

// Attach event listener to "Add to Cart" button
document.querySelector('.add-to-cart').addEventListener('click', addToCart);
