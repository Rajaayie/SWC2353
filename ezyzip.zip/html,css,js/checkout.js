	let timeLeft = 300; // Timer set to 5 minutes

function startTimer() {
    const timerElement = document.getElementById("timer");

    if (!timerElement) {
        console.error("Timer element not found.");
        return;
    }

    const interval = setInterval(() => {
        if (timeLeft <= 0) {
            clearInterval(interval);
            timerElement.innerHTML = "Time is up!";
            // Redirect to the checkout page after timer ends
            window.location.href = "checkout.html";
        } else {
            // Calculate minutes and seconds
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            timerElement.innerHTML = `Time left to complete payment: ${minutes}m ${seconds < 10 ? '0' : ''}${seconds}s`;
            timeLeft--;
        }
    }, 1000);
}


// Function to fetch and render cart details
function renderCheckoutCart() {
    // Retrieve cart data from localStorage
    const cart = JSON.parse(localStorage.getItem('cart')) || [];

    const cartDetailsContainer = document.getElementById("cartDetails");
    const finalTotalElement = document.getElementById("finalTotal");
    cartDetailsContainer.innerHTML = ""; // Clear the cart table content

    let finalTotal = 0;

    // Loop through each cart item to render them
    cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        finalTotal += itemTotal;

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.name}</td>
            <td>${item.size}</td>
            <td>${item.colour}</td>
            <td>${item.quantity}</td>
            <td>RM ${item.price.toFixed(2)}</td>
            <td>RM ${itemTotal.toFixed(2)}</td>
        `;
        cartDetailsContainer.appendChild(row);
    });

    // Display the final total
    finalTotalElement.textContent = `Final Total: RM ${finalTotal.toFixed(2)}`;
}

// Call the function on page load
window.onload = renderCheckoutCart;


